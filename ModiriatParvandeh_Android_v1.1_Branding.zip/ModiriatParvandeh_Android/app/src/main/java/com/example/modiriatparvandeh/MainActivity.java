package com.example.modiriatparvandeh;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.InputType;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, listBox, formBox;
    EditText search, fileNo, client, opponent, subject, court, date, fee, paid, notes;
    Spinner status;
    TextView stats;
    long selectedId = -1;
    int blue = 0xff0b1b33;

    int dp(int x){ return (int)(x*getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xff263445); if(bold)t.setTypeface(null,Typeface.BOLD);
        t.setPadding(dp(4),dp(5),dp(4),dp(5)); t.setGravity(Gravity.RIGHT);
        t.setTextDirection(View.TEXT_DIRECTION_RTL); return t;
    }
    EditText edit(String hint, boolean numeric) {
        EditText e = new EditText(this); e.setSingleLine(!hint.equals("یادداشت"));
        e.setHint(hint); e.setTextSize(14); e.setGravity(Gravity.RIGHT);
        e.setTextDirection(View.TEXT_DIRECTION_RTL); e.setPadding(dp(10),dp(7),dp(10),dp(7));
        if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }
    Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(v->r.run()); return b;
    }
    LinearLayout vertical(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout horizontal(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); return l; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); db=new DB(this); showHome();
    }
    void shell(String title){
        root=vertical(); root.setPadding(dp(12),dp(12),dp(12),dp(12)); root.setBackgroundColor(0xfff3f5f8);
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
        LinearLayout brand = vertical();
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(dp(8),dp(10),dp(8),dp(12));
        brand.setBackgroundColor(0xff0b1b33);
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.example.modiriatparvandeh.R.drawable.legal_brand);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(116),dp(116));
        lp.gravity = Gravity.CENTER; logo.setLayoutParams(lp); brand.addView(logo);
        TextView h=text(title,20,true); h.setTextColor(0xffffd782);
        h.setGravity(Gravity.CENTER); h.setPadding(dp(8),dp(8),dp(8),dp(8));
        brand.addView(h); root.addView(brand);
    }
    void showHome(){
        shell("مدیریت پرونده‌های وکالت");
        stats=text("",14,true); root.addView(stats); updateStats();
        LinearLayout actions=horizontal();
        actions.addView(button("پرونده جدید",()->showForm(null)));
        actions.addView(button("پشتیبان‌گیری",()->backup()));
        root.addView(actions);
        search=edit("جست‌وجو: موکل، شماره یا موضوع",false); root.addView(search);
        root.addView(button("جست‌وجو",()->loadList(search.getText().toString())));
        listBox=vertical(); root.addView(listBox); loadList("");
    }
    void updateStats(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(fee),0),COALESCE(SUM(paid),0) FROM cases",null);
        if(c.moveToFirst()) stats.setText("تعداد: "+c.getInt(0)+"   |   حق‌الوکاله: "+fmt(c.getLong(1))+
            " تومان   |   دریافتی: "+fmt(c.getLong(2))+"   |   مانده: "+fmt(c.getLong(1)-c.getLong(2))+" تومان");
        c.close();
    }
    String fmt(long n){ return NumberFormat.getInstance(Locale.US).format(n); }
    void loadList(String q){
        if(listBox==null)return; listBox.removeAllViews();
        Cursor c;
        if(q==null||q.trim().isEmpty()) c=db.getReadableDatabase().rawQuery("SELECT * FROM cases ORDER BY id DESC",null);
        else c=db.getReadableDatabase().rawQuery("SELECT * FROM cases WHERE client LIKE ? OR file_no LIKE ? OR subject LIKE ? OR opponent LIKE ? ORDER BY id DESC",
            new String[]{"%"+q+"%","%"+q+"%","%"+q+"%","%"+q+"%"});
        while(c.moveToNext()){
            final long id=c.getLong(c.getColumnIndexOrThrow("id"));
            String title=c.getString(c.getColumnIndexOrThrow("client"));
            String sub=c.getString(c.getColumnIndexOrThrow("subject"));
            long f=c.getLong(c.getColumnIndexOrThrow("fee")), p=c.getLong(c.getColumnIndexOrThrow("paid"));
            LinearLayout card=vertical(); card.setPadding(dp(8),dp(6),dp(8),dp(6)); card.setBackgroundColor(-1);
            TextView t=text(title+"  |  "+sub+"\nحق‌الوکاله: "+fmt(f)+"   دریافتی: "+fmt(p)+"   مانده: "+fmt(f-p),14,true);
            card.addView(t); card.addView(button("مشاهده / ویرایش",()->editCase(id)));
            listBox.addView(card);
            View line=new View(this); line.setBackgroundColor(0xffd9e1ea); line.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(1))); listBox.addView(line);
        }
        c.close();
    }
    void showForm(Cursor row){
        selectedId=-1; shell("ثبت پرونده");
        fileNo=edit("شماره پرونده",false); client=edit("نام موکل *",false); opponent=edit("طرف مقابل",false);
        subject=edit("موضوع پرونده *",false); court=edit("شعبه / مرجع رسیدگی",false); date=edit("تاریخ شروع",false);
        fee=edit("حق‌الوکاله به تومان",true); paid=edit("مبلغ دریافتی به تومان",true);
        notes=edit("یادداشت",false); notes.setSingleLine(false); notes.setMinLines(3);
        addField("شماره پرونده",fileNo); addField("نام موکل",client); addField("طرف مقابل",opponent);
        addField("موضوع پرونده (حقوقی، کیفری، خانواده، ملکی، ثبتی، تجاری و ...)",subject);
        addField("شعبه / مرجع رسیدگی",court); addField("تاریخ شروع",date);
        addField("حق‌الوکاله (تومان)",fee); addField("مبلغ دریافتی (تومان)",paid);
        status=new Spinner(this); String[] statuses={"در جریان","مختومه","در انتظار اقدام","توقف‌شده"};
        status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,statuses));
        root.addView(text("وضعیت پرونده",13,true)); root.addView(status);
        addField("یادداشت",notes);
        root.addView(button("ذخیره پرونده",()->save()));
        root.addView(button("بازگشت",()->showHome()));
        if(row!=null){ /* populated by editCase */ }
    }
    void addField(String label, EditText e){ root.addView(text(label,12,true)); root.addView(e); }
    void editCase(long id){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT * FROM cases WHERE id=?",new String[]{""+id});
        if(!c.moveToFirst()){c.close();return;}
        showForm(null); selectedId=id;
        fileNo.setText(c.getString(c.getColumnIndexOrThrow("file_no")));
        client.setText(c.getString(c.getColumnIndexOrThrow("client")));
        opponent.setText(c.getString(c.getColumnIndexOrThrow("opponent")));
        subject.setText(c.getString(c.getColumnIndexOrThrow("subject")));
        court.setText(c.getString(c.getColumnIndexOrThrow("court")));
        date.setText(c.getString(c.getColumnIndexOrThrow("start_date")));
        fee.setText(""+c.getLong(c.getColumnIndexOrThrow("fee")));
        paid.setText(""+c.getLong(c.getColumnIndexOrThrow("paid")));
        notes.setText(c.getString(c.getColumnIndexOrThrow("notes")));
        String st=c.getString(c.getColumnIndexOrThrow("status"));
        for(int i=0;i<status.getCount();i++) if(status.getItemAtPosition(i).toString().equals(st))status.setSelection(i);
        c.close();
        root.addView(button("حذف این پرونده",()->deleteCase(id)));
    }
    long number(EditText e){ try{return Long.parseLong(e.getText().toString().replace(",","").trim());}catch(Exception x){return 0;} }
    void save(){
        String cl=client.getText().toString().trim(), su=subject.getText().toString().trim();
        if(cl.isEmpty()||su.isEmpty()){toast("نام موکل و موضوع پرونده الزامی است.");return;}
        ContentValues v=new ContentValues();
        v.put("file_no",fileNo.getText().toString()); v.put("client",cl); v.put("opponent",opponent.getText().toString());
        v.put("subject",su); v.put("court",court.getText().toString()); v.put("start_date",date.getText().toString());
        v.put("fee",number(fee)); v.put("paid",number(paid)); v.put("notes",notes.getText().toString());
        v.put("status",status.getSelectedItem().toString());
        if(selectedId<0){v.put("created_at",System.currentTimeMillis()); db.getWritableDatabase().insert("cases",null,v);}
        else db.getWritableDatabase().update("cases",v,"id=?",new String[]{""+selectedId});
        toast("پرونده ذخیره شد."); showHome();
    }
    void deleteCase(long id){
        new AlertDialog.Builder(this).setTitle("حذف پرونده").setMessage("پرونده حذف شود؟")
            .setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{
                db.getWritableDatabase().delete("cases","id=?",new String[]{""+id}); showHome();
            }).show();
    }
    void backup(){
        // Simple shareable database copy is written to app's external files directory.
        try{
            java.io.File src=getDatabasePath("cases.db");
            java.io.File dst=new java.io.File(getExternalFilesDir(null),"backup_cases.db");
            java.nio.file.Files.copy(src.toPath(),dst.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_STREAM,android.net.Uri.fromFile(dst)); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"ارسال نسخه پشتیبان"));
        }catch(Exception e){toast("هنوز پایگاه داده‌ای برای پشتیبان‌گیری وجود ندارد.");}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"cases.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE cases(id INTEGER PRIMARY KEY AUTOINCREMENT,file_no TEXT,client TEXT,opponent TEXT,subject TEXT,court TEXT,status TEXT,start_date TEXT,fee INTEGER DEFAULT 0,paid INTEGER DEFAULT 0,notes TEXT,created_at INTEGER)");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
    }
}
